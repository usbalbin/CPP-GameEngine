	project "Bullet3Geometry"

	language "C++"
				
	kind "StaticLib"
		
	includedirs {".."}
	

	files {
		"**.cpp",
		"**.h"
	}